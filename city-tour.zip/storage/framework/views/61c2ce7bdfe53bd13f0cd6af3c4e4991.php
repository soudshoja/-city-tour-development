<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('css/perfect-scrollbar.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('css/style.css')); ?>" />
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('css/animate.css')); ?>" />
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('css/app.css')); ?>" />

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body>      

            <div>
                <?php echo e($slot); ?>

            </div>
       
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\city-tour\resources\views/layouts/guest.blade.php ENDPATH**/ ?>