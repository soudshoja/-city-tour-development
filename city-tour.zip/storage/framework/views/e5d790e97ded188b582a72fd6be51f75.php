<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\city-tour\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>